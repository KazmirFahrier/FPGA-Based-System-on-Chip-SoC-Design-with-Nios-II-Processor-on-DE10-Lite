# 🧠 FPGA-Based System-on-Chip with Nios II on DE10-Lite

This project implements a fully functional embedded **System-on-Chip (SoC)** on the **Intel DE10-Lite FPGA board** using the **Nios II soft-core processor**, developed with **Quartus Prime 16.1** and the **Nios II Software Build Tools for Eclipse**.

(Full description omitted for brevity...)
